const fs = require("fs");
const crc = require("crc");
const path = require("path");

// Function to calculate CRC32 for any file
const calculateCRCForFile = (filePath) => {
  return new Promise((resolve, reject) => {
    const stream = fs.createReadStream(filePath);
    let crc32 = null;

    // Read file in chunks
    stream.on("data", (chunk) => {
      if (crc32 === null) {
        crc32 = crc.crc32(chunk); // Initialize checksum with first chunk
      } else {
        crc32 = crc.crc32(chunk, crc32); // Update checksum for subsequent chunks
      }
    });

    // On stream end, resolve the checksum
    stream.on("end", () => {
      if (crc32 === null) {
        resolve("00000000"); // Handle empty file case
      } else {
        const checksum = crc32.toString(16).toUpperCase().padStart(8, "0");
        resolve(checksum); // Return formatted CRC32 checksum
      }
    });

    // Handle errors
    stream.on("error", (error) => {
      logger.error(`Error calculating CRC32: ${error.message}`);
      reject(error);
    });
  });
};

// Function to remove everything up to and including 'anki/' from the file path
const removeAnkiPrefix = (filePath) => {
  // Match everything up to and including 'anki/' and replace it with '/'
  return filePath.replace(/.*anki[\\/]/, "/");
};

// Function to read the index.sys file and match CRC and path
const matchCRCInIndexSysFile = (indexSysFilePath, filePath) => {
  // Calculate CRC for the given file
  calculateCRCForFile(filePath)
    .then((calculatedCRC) => {
      // Read the index.sys file
      fs.readFile(indexSysFilePath, "utf8", (err, data) => {
        if (err) {
          logger.error(`Error reading the index.sys file: ${err.message}`);
        } else {
          // Match the CRC value and file path from the file
          const regex = /^([A-F0-9]{8})\s+(\d+)\s+(.+)$/gm; // Match CRC (8 characters), size, and file path
          let match;
          let crcFound = false;

          // Loop through each matched CRC, size, and file path in the file
          while ((match = regex.exec(data)) !== null) {
            const crcFromFile = match[1]; // Extract the CRC from the file
            let filePathFromFile = match[3].trim(); // Extract and trim the file path from the index.sys file

            // Remove './anki' from both paths
            const adjustedFilePath = removeAnkiPrefix(filePathFromFile);
            const adjustedFilePathForComparison = removeAnkiPrefix(filePath);

            // Check if both CRC and adjusted file path match
            if (
              crcFromFile === calculatedCRC &&
              adjustedFilePathForComparison === adjustedFilePath
            ) {
              // Print the matching CRC and path
              logger.info(`Matching CRC: ${crcFromFile}`);
              logger.info(`Matching Path: ${adjustedFilePath}`);
              crcFound = true;
              break; // Stop checking further once a match is found
            }
          }

          if (!crcFound) {
            logger.info("No matching CRC and path found.");
          }
        }
      });
    })
    .catch((error) => {
      logger.error(`Failed to calculate CRC32 checksum: ${error.message}`);
    });
};

// Example usage
const indexSysFilePath = "C:/Users/PTC-SW1/Downloads/anki/INDEX.SYS"; // Replace with your index.sys file path
const filePath =
  "C:/Users/PTC-SW1/Downloads/anki/add/Amul_Advertisement.mp4"; // Replace with the file path you want to check

// Match CRC and path in the index.sys file
matchCRCInIndexSysFile(indexSysFilePath, filePath);
