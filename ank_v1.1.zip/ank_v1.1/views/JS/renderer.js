const { ipcRenderer } = require("electron");
let selectedDirectoryPath = ""; // Variable to store the selected directory folderLabel
const chooseDirButton = document.getElementById("chooseDirButton");
const submitButton = document.getElementById("submitButton");
const folderStatusElement = document.getElementById("statusMessage");
const folderLabel = document.getElementById("folderLabel");
const IpListContainer = document.getElementById("IpListContainer");
const sendButton = document.getElementById("SendButton");
const Database_version_name = document.getElementById("Database_version_name");
const listItem = document.querySelector(".example");

let selectedIps = [];

folderLabel.addEventListener("click", () => {
  // Simulate a click on the choose button
  chooseDirButton.click();
});
ipcRenderer.on("get-ip-addresses", (event, ipAddresses) => {
  // Clear the container before populating

  if (ipAddresses.length === 0) {
    console.log("No IP addresses found.");
    return;
  }
  createIpListItem(ipAddresses, true);
});

ipcRenderer.on("ip-status-update", (event, updatedIpData) => {
  // Clear the container before populating

  if (updatedIpData.length === 0) {
    console.log("No IP addresses found.");
    return;
  }
  createIpListItem(updatedIpData, false);
}); 


function createIpListItem(Ips_result, boolean) {

  Ips_result.forEach((ipData) => {
    // Check if the IP element already exists
    const existingItem = document.getElementById(`ip-container-${ipData.ip}`);

    if (existingItem) {
      // Update status and db-text for existing items
      const statusIcon = document.getElementById(`status-${ipData.ip}`);
      const dbVersionText = document.getElementById(`db-text-${ipData.ip}`);
      const checkbox = document.getElementById(`checkbox-${ipData.ip}`);

      // Update the checkbox and status icon
      updateCheckboxStatus(checkbox, ipData.status, ipData.ip);
      updateStatusIcon(statusIcon, ipData.status);

      // Update DB version text only if `boolean` is true
        getModuleVersion(ipData, dbVersionText);
      
    } else {
      // If the item doesn't exist, create it
      const listItem = document.createElement("div");
      listItem.classList.add("IpBox");
      listItem.id = `ip-container-${ipData.ip}`; // Assign a unique ID

      const card = document.createElement("div");
      card.classList.add("ip-card");

      const itemContainer = document.createElement("div");
      itemContainer.classList.add("IpItemContainer");

      itemContainer.innerHTML = `
        <div class="IpContent">
          <div class="CheckboxContainer">
            <input type="checkbox" id="checkbox-${ipData.ip}" class="ip-checkbox">
            <label for="checkbox-${ipData.ip}">${ipData.alianceName}</label>
          </div>
          <div class="status-container">
            <div class="status-icon" id="status-${ipData.ip}"></div>
            <div class="db-text" id="db-text-${ipData.ip}"></div>
          </div>
        </div>
      `;

      card.appendChild(itemContainer);
      listItem.appendChild(card);
      IpListContainer.appendChild(listItem);

      const statusIcon = document.getElementById(`status-${ipData.ip}`);
      const checkbox = document.getElementById(`checkbox-${ipData.ip}`);

      // Update checkbox and status icon based on the IP's status
      updateCheckboxStatus(checkbox, ipData.status, ipData.ip);
      updateStatusIcon(statusIcon, ipData.status);

      // Fetch DB version text

        const dbVersionText = document.getElementById(`db-text-${ipData.ip}`);
        getModuleVersion(ipData, dbVersionText);
  

      // Restore checkbox state if IP was previously selected
      if (selectedIps.includes(ipData.ip)) {
        checkbox.checked = true;
      }

      // Handle checkbox changes
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) {
          if (!selectedIps.includes(ipData.ip)) {
            selectedIps.push(ipData.ip); // Add the IP to the selectedIps list
          }
        } else {
          const index = selectedIps.indexOf(ipData.ip);
          if (index > -1) selectedIps.splice(index, 1); // Remove the IP from the selectedIps list
        }

        ipcRenderer.send("selectedIps", selectedIps); // Send the updated list to the main process
        console.log("Selected IPs:", selectedIps);
      });
    }
  });
}


function updateStatusIcon(statusIcon, status) {
  // Clear any existing content in the status icon container
  statusIcon.innerHTML = "";

  const img = document.createElement("img");

  // Set the image source based on the status
  if (status === "active") {
    img.src = "../assets/active.png"; // Path to your active image
    statusIcon.style.color = "green"; // Optional: keep the color if you want
  } else {
    img.src = "../assets/inactive.png"; // Path to your inactive image
    statusIcon.style.color = "red"; // Optional: keep the color if you want
  }

  // Optionally set some style for the image
  img.alt = status === "active" ? "Active" : "Inactive";
  img.style.width = "30px"; // Adjust size as needed
  img.style.height = "30px"; // Adjust size as needed

  // Append the image to the statusIcon container
  statusIcon.appendChild(img);
}

// Function to update checkbox status and background based on the IP's status
function updateCheckboxStatus(checkbox, status,ip) {

  if (status === "active") {
    checkbox.disabled = false; // Enable checkbox if status is active
    checkbox.style.backgroundColor = "white"; // Set background to white if active
  } else {
    checkbox.disabled = true; // Disable checkbox if status is not active
    checkbox.style.backgroundColor = "#ccc"; // Set background to gray if inactive
    if (checkbox.checked) {
      checkbox.checked = false; // Automatically uncheck if the status is inactive
    }

    // Remove the IP from selectedIps list if it becomes inactive
    const index = selectedIps.indexOf(ip);
    if (index > -1) selectedIps.splice(index, 1);
  }
}


// Listen for "chechBox_reset" event
ipcRenderer.on("chechBox_reset", (event, chechBox_reset) => {
  // console.log("Checkbox reset received:", chechBox_reset);
  // Uncheck all checkboxes and clear selectedIps array
  const checkboxes = document.querySelectorAll(".ip-checkbox");
  checkboxes.forEach((checkbox) => {
    checkbox.checked = false; // Uncheck all checkboxes
  });
  selectedIps.length = 0; // Clear the selectedIps array
  // Notify the main process of the updated empty list
  ipcRenderer.send("selectedIps", selectedIps);
  // console.log("Selected IPs after reset:", selectedIps);
});

ipcRenderer.on("Database_version_name", (event, version_name) => {
  Database_version_name.textContent = version_name[0];
});

// Open the directory dialog when "Choose Directory" button is clicked
chooseDirButton.addEventListener("click", () => {
  ipcRenderer.send("choose-directory"); // Request the main process to open directory dialog
});

// Listen for the selected directory from the main process
ipcRenderer.on(
  "selected-directory",
  (event, { formattedPath, selectedDirectory }) => {
    selectedDirectoryPath = selectedDirectory; // Update the selected directory
    // console.log("Selected directory inspect:", selectedDirectoryPath);

    if (folderLabel) {
      folderLabel.textContent = `${formattedPath}`; // Update the folder label
    }
  }
);
// Listen for the folder status from the main process
ipcRenderer.on(
  "folder-status",
  (event, { isValid, missingFolders, formattedPath }) => {
    if (isValid) {
      // Folder is valid
      folderStatusElement.textContent = "Folder selected successfully";
      folderStatusElement.style.color = "White";
      sendButton.disabled = false; // Enable the Send button
      sendButton.style.backgroundColor = "#2196F3"; // Set background color to blue

      // Hide Database version name while folder status is visible
      Database_version_name.style.display = "none";
    } else {
      // Folder is invalid
      folderStatusElement.textContent = "Wrong Folder Selected";
      folderStatusElement.style.color = "red";
      sendButton.disabled = true; // Disable the Send button
      sendButton.style.backgroundColor = "#ccc"; // Set background color to grey

      // Hide Database version name while folder status is visible
      Database_version_name.style.display = "none";
    }

    // Send the formatted path
    folderLabel.textContent = formattedPath;

    // Clear the folder status message after 3 seconds
    setTimeout(() => {
      folderStatusElement.textContent = "";

      // Show the Database version name after the status disappears
      Database_version_name.style.display = "block";
      
    }, 3000);
  }
);
sendButton.addEventListener("click", () => {
  // Check if any IP addresses are selected
  if (selectedIps.length === 0) {
    console.log("No IP addresses selected.");
    folderStatusElement.textContent = "Kindly choose an IP first...";
     // Prevent upload if no IP is selected
  }

  // Check both folder validity and IP selection
  if (sendButton.disabled && selectedIps.length === 0) {
    folderStatusElement.textContent =
      "Please select a valid folder and choose an IP first.";
    folderStatusElement.style.color = "red";
    console.log("Error: Both folder and IP are not selected.");
     // Prevent upload if both are missing
  }
  // Check if the folder is valid by checking if the button is enabled
  if (sendButton.disabled) {
    // console.log("Wrong folder selected.");
    folderStatusElement.textContent = "Kindly select a valid folder first.";
    folderStatusElement.style.color = "red";
    // Prevent upload if the folder is invalid
  }

  // Proceed with folder upload
  ipcRenderer.send("upload-folder", {
    selectedIps,
    selectedDirectoryPath,
  });
  // upload - status;
  ipcRenderer.once("upload-status", (event, msg) => {
    // Display a success message after the folder is uploaded (for debugging)
    // folderStatusElement.textContent = "Folder uploaded successfully!";
    folderStatusElement.textContent = msg;
    folderStatusElement.style.color = "White";

    setTimeout(() => {
      folderStatusElement.textContent = "";
    }, 3000);
  });
  // Clear the folder status message after 3 seconds
});
// Cache to store the last known version data for each IP
const versionCache = {};

function getModuleVersion(ipData, dbVersionText) {
  // console.log("Fetching version information...");
  // Check the status of the IP
  if (ipData.status === "active") {
    // If active, show the cached version (if available) while fetching the latest data
    if (versionCache[ipData.ip]) {
      // console.log("Using cached version for active IP:", ipData.ip);
      dbVersionText.textContent = versionCache[ipData.ip];
    } else {
      dbVersionText.textContent = "Loading"; // Show "Loading" only if no cached version exists
    }
    // Set up a one-time listener for the "Database_version_name_module" event
    ipcRenderer.once("Database_version_name_module", (event, version_name) => {
      const matchingVersion = version_name.find((entry) => entry.ip === ipData.ip);
      // console.log(matchingVersion.version_name, version_name);
      if (matchingVersion) {
        // Check if the fetched version is different from the cached version
        if (versionCache[ipData.ip] !== matchingVersion.version_name) {
          // If the version has changed, update the cache with the new version and display it
          dbVersionText.textContent = matchingVersion.version_name;
          versionCache[ipData.ip] = matchingVersion.version_name; // Store the latest version
        } else {
          // If the version is the same, use the cached version
          dbVersionText.textContent = versionCache[ipData.ip];
        }
      } else {
        // If no matching version is found, show the cached version or fallback message
        dbVersionText.textContent = versionCache[ipData.ip] || "DB Ver: _._._";
      }
    });


  } else {
    // For inactive status, show "DB Ver: _._._"
    dbVersionText.textContent = "DB Ver: _._._";
  }
}


