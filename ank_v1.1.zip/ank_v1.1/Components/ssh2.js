const { Client } = require("ssh2");
const fs = require("fs");
const path = require("path");

let mainWindow;
let results = []; // Define results array globally to store data for all IPs

const mainWindowfn = (window) => {
  mainWindow = window;
};

const connectToActiveHosts = (hosts) => {
  if (!mainWindow) {
    console.error("Error: mainWindow is not defined.");
    return;
  }

  // Filter out only active hosts
  const activeHosts = hosts.filter((host) => host.status === "active" && host.ip !== '192.168.0.1' && host.ip !== '192.168.0.3');

  if (activeHosts.length === 0) {
   // console.log("No active hosts found.");
    return;
  }

  // Counter to track when all hosts have been processed
  let completedHosts = 0;

  activeHosts.forEach((host) => {
    connectViaSSH(host, () => {
      // Increment counter once a host has finished processing
      completedHosts++;

      // If all hosts are processed, log the final results
      if (completedHosts === activeHosts.length) {
        logFinalResults();
      }
    });
  });
};

const connectViaSSH = (host, callback) => {
  const conn = new Client();
  const { ip, alianceName } = host;
  const privateKeyPath = path.join(__dirname, "../key/PTCS_key11.ppk");

  let connectionAttempted = false;

  const onConnectionSuccess = () => {
    // Static paths to check
    const pathsToCheck = [
      "/home/ptcs/Desktop/ppsWebsite/src/content/database/INDEX.SYS",
      "/usr/share/apache2/htdocs/content/database/INDEX.SYS",
    ];

    // Iterate through the paths and check for the INDEX.SYS file
    checkFileExists(pathsToCheck);
  };

  const onConnectionFailure = (err) => {
    if (!connectionAttempted) {
      connectionAttempted = true;
      connectWithPrivateKey(); // Try private key authentication after password fails
    } else {
      console.error(`Connection to ${ip} failed: ${err.message}`);
      conn.end(); // Close the connection on failure
    }
  };

  const connectWithPassword = () => {
    conn
      .on("ready", onConnectionSuccess)
      .on("error", onConnectionFailure)
      .connect({
        host: ip,
        port: 22,
        username: "ptcs", // Username for password authentication
        password: "ptcs", // Password for password authentication
      });
  };

  const connectWithPrivateKey = () => {
    conn
      .on("ready", onConnectionSuccess)
      .on("error", onConnectionFailure)
      .connect({
        host: ip,
        port: 22,
        username: "root", // Username for private key authentication
        privateKey: fs.readFileSync(privateKeyPath), // Private key for authentication
      });
  };

  // First try password authentication, then fallback to private key
  connectWithPassword();

  // Function to check if the file exists at the specified paths
  const checkFileExists = (paths) => {
    for (let i = 0; i < paths.length; i++) {
      const checkPath = paths[i];
      const checkFileCommand = `test -f ${checkPath} && echo "exists" || echo "not found"`;

      conn.exec(checkFileCommand, (err, stream) => {
        if (err) {
          console.error(`Error checking file at ${checkPath}:`, err);
          return;
        }

        let fileStatus = "";
        stream.on("data", (data) => {
          fileStatus += data.toString("utf-8").trim();
        });

        stream.on("close", () => {
          if (fileStatus === "exists") {
            readFileContent(checkPath); // Proceed to read the file
          }
        });
      });
    }
  };

  // Function to read the content of the INDEX.SYS file
  const readFileContent = (filePath) => {
    const readFileCommand = `/bin/bash -c "cat ${filePath}"`;

    conn.exec(readFileCommand, (err, stream) => {
      if (err) {
     //   console.error("Error reading INDEX.SYS file:", err);
        conn.end();
        return;
      }

      let fileData = "";
      stream.on("data", (data) => {
        fileData += data.toString("utf-8");
      });

      stream.on("close", () => {
        parseIndexSysData(fileData, ip, alianceName);
        conn.end(); // Close the connection after reading the file
        callback(); // Notify that this host is done processing
      });
    });
  };
};

const parseIndexSysData = (data, ip) => {
  const rows = data.split("\n");

  rows.forEach((row) => {
    row = row.trim();
    if (row === "") return;

    const parts = row.split(/\s+/);

    if (parts.length >= 3) {
      const size = parts[1];
      const filename = parts.slice(2).join(" ");

      if (size === "00000000") {
        const version_name = filename;

        // Create a JSON object for the current data
        const newData = {
          ip,
          version_name,
        };

        // Filter out existing data with the same ip
        results = results.filter((item) => item.ip !== newData.ip);

        // Add the new data to results
        results.push(newData); // Add the new data to the results array

       // console.log("Updated results:", results);
      }
    }
  });
};


// Deduplicate the results array and log the final output
const logFinalResults = () => {

  // Send the unique results to the main window (for Electron)
  if (mainWindow && mainWindow.webContents) {
    mainWindow.webContents.send("Database_version_name_module", results);
  }
 // console.log(results)
}

module.exports = { connectToActiveHosts, mainWindowfn };
