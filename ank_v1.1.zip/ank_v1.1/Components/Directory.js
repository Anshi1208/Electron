const { ipcMain, dialog } = require("electron");
const { checkIndexSysForZeroSize } = require("./VersionCheck");
const fs = require("fs");
const path = require("path");
const { incrementVersion } = require("./incrementVersion.js");
const requiredSubfolders = [
  "INDEX.SYS",
  "videoAdvertismentTime.txt",
  "add",
  "add2",
  "poster",
  "videos",
  "kidszone",
  "img",
  "music",
  "movies",
  "advertisment",
];

async function chooseDirectory(mainWindow) {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ["openDirectory"],
  });

  if (!result.canceled) {
    const directoryPath = result.filePaths[0];
    mainWindow.webContents.send("directory-chosen", directoryPath);
    handleDirectorySelection(directoryPath, mainWindow);
  }
}

function handleDirectorySelection(selectedDirectory, mainWindow) {
  // console.log("Received selectedDirectory:", selectedDirectory);

  // Ensure the directory exists
  if (!fs.existsSync(selectedDirectory)) {
    return;
  }

  const directoryParts = selectedDirectory.split(path.sep);

  checkIndexSysForZeroSize(selectedDirectory, mainWindow);

  const formattedPath = `${directoryParts[0]}\\${directoryParts[1]}\\...\\${
    directoryParts[directoryParts.length - 2]
  }\\${directoryParts[directoryParts.length - 1]}`;

  const missingFolders = checkSubfolders(selectedDirectory);

  mainWindow.webContents.send("selected-directory", {
    formattedPath,
    selectedDirectory,
  });

  if (missingFolders.length === 0) {
    mainWindow.webContents.send("folder-status", {
      isValid: true,
      formattedPath: formattedPath,
    });

    printIndexSysFile(selectedDirectory, mainWindow);
  } else {
    mainWindow.webContents.send("folder-status", {
      isValid: false,
      missingFolders: missingFolders,
      formattedPath: formattedPath,
    });
  }
}

/**
 * Upload files listed in INDEX.SYS recursively.
 */ /**
 * Upload files listed in INDEX.SYS recursively.
 */

async function uploadFilesFromIndexSys(directory) {
  const indexSysPath = path.join(directory, "INDEX.SYS");

  if (!fs.existsSync(indexSysPath)) {
    console.error("INDEX.SYS file not found.");
    return;
  }

  const indexContents = await fs.readFileSync(indexSysPath, "utf8");
  const lines = indexContents.split("\n");
  let localPath = [];
  let remotePath = [];
  let textFileSize = [];
  let textCrc = [];
  let updatedData = "";
  let versionUpdated = false;

  lines.forEach((line) => {
    if (line.includes("DB Ver:")) {
      const updatedLine = incrementVersion(line)
      // console.log("update version line ", updatedLine);

      updatedData += updatedLine + "\n";
      versionUpdated = true;
      return;
    }

    updatedData += line + "\n";

    if (!versionUpdated) {
      console.log("no  version line found ",)
    }

    fs.promises.writeFile(indexSysPath, updatedData.trim() + "\n", {
      encoding: "utf8",
    });

    const parts = line.match(/^([A-F0-9]{8})\s+(\d+)\s+(.*)$/);
    if (parts && parts.length === 4) {
      const filename = parts[3].trim();
      const crc = parts[1];
      const size = parts[2];
      if (!localPath.includes(filename)) {
        localPath.push(filename);
        remotePath.push(filename);
        textFileSize.push(size);
        textCrc.push(crc);
      }
    }
  });
  localPath = localPath
    .filter((path) => path !== "FILENAME")
    .map((path) => (path.startsWith("/") ? path.substring(1) : path));

  remotePath = remotePath
    .filter((path) => path !== "FILENAME")
    .map((path) => {
      const parts = path.split("/");
      const lowercaseParts = parts.map((part, index) => {
        return index === parts.length - 1 ? part : part.toLowerCase();
      });
      return lowercaseParts.join("/");
    });

  // Ensure valid line with CRC, size, and file path
  // console.log("Local Paths:", localPath);
  //  console.log("Remote Paths:", remotePath);
  // console.log("File Sizes:", textFileSize);
  // console.log("CRC Values:", textCrc);

  const localPaths = localPath.map((localPath) =>
    path.join(directory, localPath)
  );
  // console.log("Local Paths:", localPaths);
  return { localPaths, remotePath, textFileSize, textCrc };
}

function checkSubfolders(directory) {
  try {
    // Read the folder and file names in the selected directory (case-insensitive)
    const folderNames = fs
      .readdirSync(directory)
      .map((name) => name.toLowerCase());

    // Check for missing required subfolders (case-insensitive)
    const missingFolders = requiredSubfolders.filter(
      (subfolder) => !folderNames.includes(subfolder.toLowerCase())
    );

    return missingFolders;
  } catch (error) {
    console.error("Error while checking subfolders:", error);
    return requiredSubfolders; // Return all folders as missing in case of error
  }
}

// Function to upload files to IPs
function uploadFilesToIPs(directory) {
  console.log(`Uploading files from directory: ${directory}`);

  // Example logic for file upload (replace with actual implementation)
  const files = fs.readdirSync(directory);
  files.forEach((file) => {
    const filePath = path.join(directory, file);
    const stats = fs.statSync(filePath);

    if (stats.isFile()) {
      console.log(`Uploading file: ${filePath}`);
      // Add logic to upload files to the IP
    } else if (stats.isDirectory()) {
      console.log(`Skipping subdirectory: ${filePath}`);
    }
  });
}

// Function to print the contents of the INDEX.SYS file
function printIndexSysFile(directory, mainWindow) {
  const indexFilePath = path.join(directory, "INDEX.SYS");

  if (fs.existsSync(indexFilePath)) {
    const indexContent = fs.readFileSync(indexFilePath, "utf8");
    // console.log("Contents of INDEX.SYS:", indexContent);

    // Optionally send content to the renderer
    mainWindow.webContents.send("index-sys-content", indexContent);
  } else {
    console.warn("INDEX.SYS file not found in the directory.");
  }
}

module.exports = {
  chooseDirectory,
  handleDirectorySelection,
  checkSubfolders,
  uploadFilesFromIndexSys,
};
