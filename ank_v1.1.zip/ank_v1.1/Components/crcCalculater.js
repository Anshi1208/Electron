
const path = require("path");
const fs = require("fs");
const crc = require("crc");


const calculateFileCRC32 = async (filePath) => {
  // Calculate CRC32 checksum for a file
  return new Promise((resolve, reject) => {
    const stream = fs.createReadStream(filePath);
    let crc32 = null; // Initialize crc32 as null

    stream.on("data", (chunk) => {
      if (crc32 === null) {
        crc32 = crc.crc32(chunk);
      } else {
        crc32 = crc.crc32(chunk, crc32);
      }
    });

    stream.on("end", () => {
      if (crc32 === null) {
        resolve("00000000"); // Handle case where no data was read
      } else {
       
        const checksum = crc32.toString(16).toUpperCase().padStart(8, "0");
        resolve(checksum);
      }
    });

    stream.on("error", (error) => {
      console.error(
        `calculateFileCRC32: Error calculating CRC32: ${error.message}`
      );

      reject(error);
    });
  });
};

module.exports = {
  calculateFileCRC32,
};
