const fs = require("fs");
const { Client } = require("ssh2");
const ping = require("ping");
const path = require("path");
// SFTP connection details
const privateKeyPath = path.join(__dirname, "../key/PTCS_key11.ppk"); // Adjust the private key path as necessary

async function connection(ipAddress) {
  return new Promise((resolve, reject) => {
    const conn = new Client();

    // Try to connect with private key
    const tryPrivateKey = () => {
      const privateKey = fs.readFileSync(privateKeyPath);
      conn.connect({
        host: ipAddress,
        username: "root",
        privateKey: privateKey,
      });
    };

    // Try to connect with alternative username and password
    const tryUsernamePassword = () => {
      conn.connect({
        host: ipAddress,
        username: "ptcs",
        password: "ptcs", // Replace 'ptcs' with the actual password if necessary
      });
    };

    conn
      .on("ready", () => {
      //  console.log(`Connected successfully to ${ipAddress}`);
        resolve(conn);
      })
      .on("error", (err) => {
        if (err.level === "client-authentication") {
          // Retry with username 'ptcs' and password if private key fails
          // console.warn(
          //   `connection: Private key authentication failed for ${ipAddress}, retrying with username 'ptcs' and password`
          // );
          tryUsernamePassword();
        } else {
          console.error(
            `connection: SFTP connection error to ${ipAddress}: ${err.message}`
          );
          console.log(err);
          reject(err);
        }
      });

    // Start by trying the private key
    tryPrivateKey();
  });
}

async function uploadFile(sftp, localPath, remotePath) {
  return new Promise((resolve, reject) => {
    sftp.fastPut(localPath, remotePath, (err) => {
      if (err) {
        console.error(
          `uploadFile: Error uploading file from ${localPath} to ${remotePath}: ${err.message}`
        );
        reject(err);
      } else {
        // console.log(
        //   ` File successfully uploaded`
        // );
        resolve();
      }
    });
  });
}

async function checkRemoteFileExists(sftp, remotePath) {
  return new Promise((resolve, reject) => {
    sftp.stat(remotePath, (err, stats) => {
      if (err) {
        if (err.code === 2) {
          // No such file or directory
        //  console.error(`checkRemoteFileExists: Error No such file or directory ${err.message}`);
          resolve(false);
        } else {
          // console.error(`checkRemoteFileExists: Error checking remote file existence for ${remotePath}: ${err.message}`);
          reject(err);
        }
      } else {
        // console.log(`checkRemoteFileExists: Remote file exists: ${remotePath}`);
        resolve(true);
      }
    });
  });
}

async function findContentFolder(conn) {
  return new Promise((resolve, reject) => {
    const command = `
      find / -type d -name "content" -exec sh -c '
        for dir; do
          if [ -d "$dir/movies" ] && [ -d "$dir/poster" ] && [ -d "$dir/music" ]; then
            echo "$dir"
          fi
        done
      ' sh {} + || echo "No matching folders found"
    `;

    conn.exec(command, (err, stream) => {
      if (err) {
        console.error("findContentFolder: Error executing SSH command");
        return reject(err);
      }

      let output = "";

      stream
        .on("close", (code, signal) => {
          if (code === 0) {
            // console.log("findContentFolder: Command executed successfully");
          } else {
            console.warn(`findContentFolder: Command failed with code ${code}`);
          }

          // Filter and extract valid folder paths
          const lines = output.split("\n").filter((line) => {
            const trimmedLine = line.trim();
            return (
              trimmedLine.startsWith("/") &&
              trimmedLine.includes("/content") &&
              !trimmedLine.includes("logout")
            );
          });

          const cleanedPaths = lines.map((line) => line.replace(/\r/g, ""));
          // resolve(cleanedPaths)

          // Set ServerContentPath to the first valid folder with /src/content
          if (cleanedPaths.length > 0) {
            const ServerContentPath = cleanedPaths[0]; // Use the first valid path
            // console.log(`findContentFolder: ServerContentPath set to ${ServerContentPath}`);
            resolve(ServerContentPath);
          } else {
            console.warn(
              "findContentFolder: No valid folder containing /src/content found"
            );
            resolve(null); // Return null if no valid folder is found
          }
        })
        .on("data", (data) => {
          output += data.toString();
        })
        .on("error", (err) => {
          console.error("findContentFolder: Error during stream processing");
          reject(err);
        });
    });
  });
}

module.exports = {
  connection,
  uploadFile,
  checkRemoteFileExists,
  findContentFolder,
};
