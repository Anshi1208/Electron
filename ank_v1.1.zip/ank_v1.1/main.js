const { app, BrowserWindow, ipcMain, Menu, dialog, screen } = require("electron");
const fs = require("fs");
const path = require("path");
const { mainWindowfn, connectToActiveHosts } = require("./Components/ssh2");
const ProgressBar = require("electron-progressbar");
const { extractIpAddresses, pingAllHosts } = require("./Components/Connection");
const {
  chooseDirectory,
  handleDirectorySelection,
  checkSubfolders,
  uploadFilesFromIndexSys,
} = require("./Components/Directory");
const {calculateFileCRC32} = require("./Components/crcCalculater")
const { connection,
  uploadFile,
  checkRemoteFileExists,
  findContentFolder, } = require('./Components/sftp')

  let mainWindow;
  let progressBar;
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 850,
    height: 600,
    title: "PTCS SPUT Tool",
    icon: path.join(__dirname, "./assets/pt_logo.jpg"),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });

  mainWindow.loadFile("./views/index.html");
  createMenu();
}

function createMenu() {
  const menuTemplate = [
    {
      label: "File",
      submenu: [
        {
          label: "Choose Directory",
          accelerator: "Ctrl+D",
          click: () => chooseDirectory(mainWindow),
        },
        { type: "separator" },
        { role: "quit" },
      ],
    },
    {
      label: "Tools",
      submenu: [
        {
          label: "Open Toggle Developer Tools",
          accelerator: "CmdOrCtrl+I",
          click: () => {
            mainWindow.webContents.toggleDevTools();
          },
        },
        {
          label: "Refresh",
          accelerator: "CmdOrCtrl+R",
          click: () => {
            mainWindow.reload();
          },
        },
      ],
    },
  ];
  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(async () => {
  const ipAddresses = await extractIpAddresses();
  const initialIpStatuses = await pingAllHosts(ipAddresses);
  startPingInterval(ipAddresses);
  createWindow();
  mainWindowfn(mainWindow);
  connectToActiveHosts(initialIpStatuses);
  mainWindow.webContents.send("get-ip-addresses", initialIpStatuses);
});

function startPingInterval(ipAddresses) {
  setInterval(async () => {
    const updatedHosts = await pingAllHosts(ipAddresses);
    connectToActiveHosts(updatedHosts);
    mainWindow.webContents.send("ip-status-update", updatedHosts);
  }, 5000);
}

ipcMain.on("selectedIps", (event, selectedIps) => {
  console.log("Selected IPs:", selectedIps);
  //console.log("hellooooo",selectedIps)
});

ipcMain.on("upload-folder",async (event, { selectedIps, selectedDirectoryPath }) => {
  let local, remote;
  let crcMismatchFound = false;
  let connectionErrors = []; // To track connection errors
  const paths = await uploadFilesFromIndexSys(selectedDirectoryPath);
  let existingFileCount = 0;
  const totalFiles = paths.localPaths.length * selectedIps.length;
  progressBarClosed = false;
  if (!selectedDirectoryPath) {
    event.reply("upload-status", "No folder selected!");
    return;
  }

  if (selectedIps.length === 0) {
    event.reply("upload-status", "No IP addresses selected!");
    return;
  }
  let completedFiles = 0;
  const progressBar = new ProgressBar({
    indeterminate: false,
    text: "Uploading files...",
    detail: "Initializing...",
    maxValue: totalFiles,
    browserWindow: {
      parent: mainWindow,
      modal: false,
      // alwaysOnTop: true,
      minimizable: true,
      resizable: false,
      maximizable: true,
      closable: true,
      icon: "./assets/pt_logo.ico",
      backgroundColor: "#FAF6F0",
    },
  });

  progressBar
    .on("completed", () => {
      console.log("Upload complete");
      progressBar.detail = "Upload complete";
      progressBarClosed = true; // Set flag to indicate progress bar is closed
    })
    .on("aborted", () => {
      console.log("Upload aborted");
      progressBarClosed = true; // Set flag to indicate progress bar is closed
    })
    .on("progress", (value) => {
      progressBar.detail = `Uploading file ${value} of ${totalFiles}`;
    });

  const updateProgressBar = () => {
    completedFiles++;
    progressBar.value = completedFiles;

    if (completedFiles === totalFiles) {
      progressBar.setCompleted();
    }
  };

  const indexSysPath = path.join(selectedDirectoryPath, "INDEX.SYS");
  const videoAdvertismentPath = path.join(
    selectedDirectoryPath,
    "videoAdvertismentTime.txt"
  );
  let errorShown = false; // Initialize errorShown to prevent multiple notifications

  // Map over selected IPs and create upload tasks
  const uploadTasks = selectedIps.map(async (ip) => {
    try {
      // console.log(`Attempting to connect to ${ip}...`);
      const conn = await connection(ip); // Establish SSH connection
      // console.log(`SFTP connection established to ${ip}`);
      // Obtain SFTP client
      const sftp = await new Promise((resolve, reject) => {
        conn.sftp((err, sftp) => {
          if (err) {
            console.error(`Error obtaining SFTP client for ${ip}: ${err}`);
            conn.end();
            reject(err);
          } else {
            resolve(sftp);
          }
        });
      });

      if (!paths || !paths.localPaths || paths.localPaths.length === 0) {
        console.log("No files found to process.");
        return;
      }

      const { localPaths, remotePath, textCrc } = paths;
      const validContentDirs = await findContentFolder(conn);

      // Use a fallback path if validContentDirs is null
      const ServerContentPath =
        validContentDirs || "/home/ptcs/Desktop/ppsWebsite/src/content";

      // Process all files for this IP in parallel
      const fileUploadTasks = localPaths.map(async (local, index) => {
        const remote = ServerContentPath + remotePath[index];
        const expectedCrc = textCrc[index]; // Corresponding CRC from INDEX.SYS

        try {
          const calculatedCrc = await calculateFileCRC32(local);
          const exists = await checkRemoteFileExists(sftp, remote);
          if (!exists) {
            // console.log(`File successfully uploaded to ${ip}: ${remote}`);
            if (calculatedCrc === expectedCrc) {
              await uploadFile(sftp, local, remote);
              // console.log(`CRC matched for ${local}.`);
            } else {
              // console.log(`CRC mismatch for ${local}. Expected ${expectedCrc}, got ${calculatedCrc}. Skipping upload.`);
              crcMismatchFound = true;
            }
          } else {
            existingFileCount++;
            // console.log(`File already exists on ${ip}, skipping upload.`);
          }
          updateProgressBar();
        } catch (err) {
          if (!errorShown) {
            if (err.code === "ENOENT") {
              const PathParsing = path.parse(err.path);
              const errPath = path.join(
                path.basename(PathParsing.dir),
                PathParsing.base
              );
              await dialog.showMessageBox(mainWindow, {
                type: "error",
                title: "File Not Found",
                message: `Error: File not found. Could not open ${errPath}`,
                buttons: ["OK"],
              });
              console.log(`File not found: ${errPath}`);
            } else {
              console.log(
                `Error uploading file to ${ip} from ${local} to ${remote}:`,
                err
              );
              await dialog.showMessageBox(mainWindow, {
                type: "error",
                title: "File Transfer Error",
                message: `Error uploading file`,
                buttons: ["OK"],
              });
              if (progressBar) progressBar.close();
              activeSelectedIPs = [];
            }
            // Set the flag to prevent showing the dialog again
          }
          updateProgressBar();
        }
      });
      // Wait for all file uploads for this IP to finish
      await Promise.all(fileUploadTasks);
      try {
        await fs.promises.access(indexSysPath);
      } catch (err) {
        await dialog.showMessageBox(mainWindow, {
          type: "error",
          title: "File Not Found",
          message: `Error: Configuration file not found at ${indexSysPath}. Please ensure the file exists.`,
          buttons: ["OK"],
        });
      }
      await uploadFile(
        sftp,
        indexSysPath,
        `${ServerContentPath}/database/INDEX.SYS`
      );
      await uploadFile(
        sftp,
        videoAdvertismentPath,
        `${ServerContentPath}/database/videoAdvertismentTime.txt`
      );
      // console.log(`All files uploaded to ${ip}. Connection closed.`);
      conn.end(); // Close the connection after processing all files
       if (progressBar) progressBar.close();
    } catch (err) {
      console.log(`Error with connection or file transfer to ${ip}:, ${err} `);
      await dialog.showMessageBox(mainWindow, {
        type: "error",
        title: "Connection Loss",
        message: `Connection to ${ip} lost. Please check the connection and try again.`,
        buttons: ["OK"],
      });
      if (progressBar) progressBar.close(); // Close the progress bar on connection error
    }

    // Ensure progress bar is updated even if there's an error
    updateProgressBar();
  });

  // Wait for all upload tasks across all IPs to finish
  await Promise.all(uploadTasks);
  // Show CRC mismatch dialog if found
  if (crcMismatchFound) {
    dialog.showErrorBox("Error", "Some files had CRC mismatches.");
  }

  // Show skipped files warning
  if (existingFileCount > 0) {
    await dialog.showMessageBox(mainWindow, {
      type: "warning",
      title: "Skip Files",
      message: `The Destination already has ${existingFileCount} out of ${totalFiles} files.`,
      buttons: ["OK"],
    });
  }

  // Show connection errors, if any
  if (connectionErrors.length > 0) {
    const errorMessage = connectionErrors
      .map((error) => `IP: ${error.ip} - ${error.error}`)
      .join("\n");

    await dialog.showMessageBox(mainWindow, {
      type: "error",
      title: "Connection Issues",
      message: `The following connection issues occurred:\n\n${errorMessage}`,
      buttons: ["OK"],
    });
  }
  event.reply("upload-status", "Upload process completed.");
  event.reply("chechBox_reset", []);
});

// Handle SFTP connection errors
ipcMain.on('sftp-connection-error', (event, errorMessage) => {
  dialog.showMessageBox({
    type: 'error',
    title: 'SFTP Connection Error',
    message: `An error occurred while connecting to the SFTP server:\n${errorMessage}`,
    buttons: ['OK'],
  })
})

ipcMain.on("choose-directory", async () => {
  await chooseDirectory(mainWindow);
});

ipcMain.on("zero-size-files", (event, zeroSizeFiles) => {
  console.log("Received zero-size files:", zeroSizeFiles);
});
// Simulated file upload function (replace with actual upload logic)
async function uploadFileToIp(file, ip) {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`Successfully uploaded ${file} to ${ip}`);
      resolve();
    }, 2000); // Simulate upload delay
  });
}
