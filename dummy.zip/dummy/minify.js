import fs from 'fs';
import { minify } from 'terser';
import path from 'path';

const minifyCode = async () => {
  try {
    // Read all files in the './src/Api/' directory
    const files = await fs.promises.readdir('./Api');
    
    // Ensure the output directory exists
    await fs.promises.mkdir('./dist/Api', { recursive: true });

    // Process each file in the directory
    for (const file of files) {
      const filePath = path.join('./Api', file); // Full path to the file
      const outputFilePath = path.join('./dist/Api', file); // Output path for the file

      // Check if the file is .env or .json and copy them directly
      if (file.endsWith('.env') || file.endsWith('.json')) {
        try {
          // Read the current file
          const code = await fs.promises.readFile(filePath);
          
          // Copy the file to the output directory
          await fs.promises.writeFile(outputFilePath, code);
          console.log(`Copied file: ${filePath} to ${outputFilePath}`);
        } catch (err) {
          console.error(`Error copying file ${filePath}: ${err.message}`);
        }
        continue; // Skip the minification process for .env and .json files
      }

      // Check if the file has a JavaScript-compatible extension
      if (!file.endsWith('.js') && !file.endsWith('.jsx') && !file.endsWith('.mjs')) {
        console.log(`Skipping non-JS file: ${file}`);
        continue;
      }

      try {
        // Read the current file
        const code = await fs.promises.readFile(filePath, 'utf8');
        
        // Log the file being processed
        console.log(`Processing file: ${filePath}`);
        
        // Minify the code using Terser
        const result = await minify(code);

        // Save the minified code to a new file in the dist/Api folder
        await fs.promises.writeFile(outputFilePath, result.code);
        console.log(`Minification complete. Output file: ${outputFilePath}`);
      } catch (err) {
        console.error(`Error processing file ${filePath}: ${err.message}`);
      }
    }
  } catch (err) {
    console.error('Error during minification:', err.message);
  }
};

minifyCode();

