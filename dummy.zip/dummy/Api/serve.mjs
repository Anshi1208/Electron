import { exec, spawn } from 'child_process';
import fs from 'fs';
import { fileURLToPath } from 'url';
import path from 'path'
import loadEnv from './loadEnv.js'
// Get the directory name from the module's URL
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
// Load environment variables from .env file if present
// dotenv.config();

const envPath = ['./.env', '../.env']; // Define your custom search paths

// Call the loadEnv function with custom paths
const result = loadEnv(envPath);

// Set the default port to 5173 if process.env.PORT is not defined
const port = process.env.VITE_PORT || 5173;


// Paths to check for dist folder
const distPath1 = path.join(__dirname, './dist');
const distPath2 = path.join(__dirname, '../dist');
const distPath3 = path.join(__dirname, '../../dist');

// Paths to check for server.js
const serverPath1 = path.join(__dirname, './Api/server.js');
const serverPath2 = path.join(__dirname, '../Api/server.js');
const serverPath3 = path.join(__dirname, '../../src/Api/server.js');



// Check if the `dist` folder exists
let distPathToUse;
if (fs.existsSync(distPath1)) {
    // console.log(`Path 1 ${distPath1} exists.`);
    distPathToUse = distPath1;
} else if (fs.existsSync(distPath2)) {
    // console.log(`Path 2 ${distPath2} exists.`);
    distPathToUse = distPath2;
}
else if (fs.existsSync(distPath3)) {
    // console.log(`Path 3 ${distPath3} exists.`);
    distPathToUse = distPath3;
} else {
    console.error('Neither dist path exists.');
    // process.exit(1); // Exit the process if neither path is found
}

// Check if the `server.js` file exists
let serverPathToUse;
if (fs.existsSync(serverPath1)) {
    // console.log(`Server 1 file ${serverPath1} exists.`);
    serverPathToUse = serverPath1;
} else if (fs.existsSync(serverPath2)) {
    // console.log(`Server 2 file ${serverPath2} exists.`);
    serverPathToUse = serverPath2;
}else if (fs.existsSync(serverPath3)) {
    // console.log(`Server 3 file ${serverPath3} exists.`);
    serverPathToUse = serverPath3;
} else {
    console.error('Neither server.js path exists.');
    // process.exit(1); // Exit the process if the server file is not found
}

// Debug: Log the resolved paths
// console.log("Serving dist folder at:", distPathToUse);
// console.log("Starting server at:", serverPathToUse);

// Start `server.js` in the `Api` folder
const serverProcess = spawn('node', [serverPathToUse], { stdio: 'inherit' });

serverProcess.on('error', (error) => {
    console.error(`Server Error: ${error.message}`);
});

serverProcess.on('close', (code) => {
    console.log(`Server process exited with code ${code}`);
});

// Start the `serve` command for the `dist` folder
// const serveProcess = spawn('npx', ['serve', '-s', distPathToUse, '-l', port], { stdio: 'inherit' ,shell:true});

const serveProcess = spawn('npx', ['vite', 'preview', '--host', '--port', port,'--outDir',distPathToUse], {
    stdio: 'inherit',
    shell: true,
});


serveProcess.on('error', (error) => {
    console.error(`Serve Error: ${error.message}`);
});

serveProcess.on('close', (code) => {
    console.log(`Serve process exited with code ${code}`);
});





















// import { exec } from 'child_process';
// import dotenv from 'dotenv';

// // Load environment variables from .env file if present
// dotenv.config();

// // Set the default port to 5173 if process.env.PORT is not defined
// const port = process.env.PORT || 5173;

// // Execute the serve command with the specified port
// exec(`serve -s dist -l ${port}`, (error, stdout, stderr) => {
//     if (error) {
//         console.error(`Error: ${error.message}`);
//         return;
//     }
//     if (stderr) {
//         console.error(`Stderr: ${stderr}`);
//         return;
//     }
//     console.log(`Stdout: ${stdout}`);
// });
