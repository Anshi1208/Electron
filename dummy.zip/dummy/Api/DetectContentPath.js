/* eslint-disable no-unused-vars */
import fs from 'fs'
import path from 'path'

import { fileURLToPath } from 'url'
// Get the directory name from the module's URL
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const DetectContentPath = (app) => {
  // Define possible paths
  const contentPath1 = path.join(__dirname, '../src/content/')
  const contentPath2 = path.join(__dirname, '../../src/content/')

  // Determine the active path
  let activePath
  if (fs.existsSync(contentPath1)) {
    activePath = contentPath1
  } else if (fs.existsSync(contentPath2)) {
    activePath = contentPath2
  } else {
    throw new Error('No valid content path found.')
  }
  return { activePath, __dirname }
}

export default DetectContentPath
