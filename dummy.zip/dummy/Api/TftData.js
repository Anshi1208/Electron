import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

// Define __dirname for ES module compatibility
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const TftData = (app) => {
  // Endpoint to fetch the data for media files (image/video)
  app.get("/tft/data", (req, res) => {
    const dataPath = path.join(__dirname, "../src/content/add2/");

    fs.readdir(dataPath, { withFileTypes: true }, (err, files) => {
      if (err) {
        console.error("Error reading folder:", err);
        return res.status(500).json({ error: "Failed to read folder" });
      }

      // Collect file paths and types
      const fileData = files.map((file) => ({
        name: file.name,
        type: file.isDirectory()
          ? "directory"
          : path.extname(file.name).toLowerCase().slice(1), // Get file type (image/video/audio)
      }));

      res.json(fileData);
    });
  });

  // Endpoint to fetch media file by name (for displaying images/videos)
  app.get("/tft/media/:fileName", (req, res) => {
    const { fileName } = req.params;
    const mediaPath = path.join(__dirname, "../src/content/add2/", fileName);

    fs.stat(mediaPath, (err, stats) => {
      if (err) {
        console.error("Error accessing file:", err);
        return res.status(404).json({ error: "File not found" });
      }

      // Check if the file exists and is accessible
      if (stats.isFile()) {
        res.sendFile(mediaPath);
      } else {
        return res.status(404).json({ error: "Not a valid file" });
      }
    });
  });
};

export default TftData;
