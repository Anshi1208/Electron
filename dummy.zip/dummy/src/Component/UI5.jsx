/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import "@css/UI5.css";
import img1 from "@content/add2/left.jpg";
import img2 from "@content/add2/train.jpg";
import vdo1 from "@content/add2/Chutki.mp4";
import vdo2 from "@content/add2/Coca_Cola_to_Turn_Up_the_Moment.mp4";
import vdo3 from "@content/add2/Fevikwik_Phenko_Nahi_Jodo.mp4";
import vdo4 from "@content/add2/Kalia Ustaad2.mp4";

const UI5 = () => {
  const [showImage, setShowImage] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const videoRef = useRef(null);

  // Arrays to hold the images and videos
  const images = [img1, img2];
  const videos = [vdo1, vdo2, vdo3, vdo4];

  const handleMediaEnd = () => {
    const isVideo = Math.random() > 0.5; // Randomly choose between video or image
    setShowImage(isVideo ? false : true); // Set the media type
    if (isVideo) {
      setCurrentIndex(Math.floor(Math.random() * videos.length)); // Random video index
    } else {
      setCurrentIndex(Math.floor(Math.random() * images.length)); // Random image index
    }
  };

  useEffect(() => {
    if (videoRef.current && !showImage) {
      videoRef.current.onended = handleMediaEnd;
    }
  }, [showImage]);

  useEffect(() => {
    // If an image is shown, switch it after 5 seconds
    if (showImage) {
      const timer = setTimeout(() => {
        setShowImage(false); // Switch to video after 5 seconds
        setCurrentIndex(Math.floor(Math.random() * videos.length)); // Random video index
      }, 5000); // 5 seconds delay for image

      return () => clearTimeout(timer); // Cleanup the timer on component unmount
    }
  }, [showImage]);

  return (
    <div className="main-container">
      {/* Video or Image Section */}
      <div className="video-section">
        {showImage ? (
          <img
            className="image-player"
            src={images[currentIndex]}
            alt="Station"
          />
        ) : (
          <video
            ref={videoRef}
            autoPlay
            muted
            className="video-player"
            src={videos[currentIndex]}
          />
        )}
      </div>
    </div>
  );
};

export default UI5;
