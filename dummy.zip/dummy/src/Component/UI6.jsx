/* eslint-disable no-unused-vars */
import React from "react";
import "@css/UI6.css";

const UI6 = () => {
  return (
    <div className="main-container">
      <div className="text-message fullscreen">
        <h1>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum quas quam
          alias debitis molestiae rerum totam cupiditate inventore, magnam nihil
          assumenda ab veniam doloribus, officiis voluptatibus qui! Debitis
          labore cumque minus delectus ipsum, quas, aut asperiores dicta
          molestiae saepe nobis deleniti recusandae qui voluptatem dolores autem
          ab voluptatum perspiciatis veritatis.
        </h1>
      </div>
    </div>
  );
};

export default UI6;
