import  { useState, useEffect, useRef } from "react";
import "@css/UI3.css";

const UI2 = () => {
  const [mediaFiles, setMediaFiles] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [mediaType, setMediaType] = useState("video"); // Track the current media type (video/image)
  const [showImage, setShowImage] = useState(false); // Track if the image is currently shown
  const videoRef = useRef(null);

  const getRandomIndex = (arrayLength) =>
    Math.floor(Math.random() * arrayLength);

  const getRandomMediaType = () => (Math.random() > 0.5 ? "image" : "video"); // Randomly select between image and video

  const switchMedia = () => {
    console.log("Switching media...");
    setMediaType(getRandomMediaType()); // Randomly choose next media type (video/image)
    setCurrentIndex(getRandomIndex(mediaFiles.length)); // Pick a random media file
    setShowImage(false); // Hide image initially when switching
  };

  const handleVideoEnd = () => {
    console.log("Video ended. Showing image...");
    setShowImage(true); // Show image after video ends
    setMediaType("image"); // Change media type to image after video ends
  };

  useEffect(() => {
    // Fetch media files from the API
    const fetchData = async () => {
      try {
        const response = await fetch("/api/tft/data");
        const data = await response.json();
        console.log("Fetched media files:", data);
        setMediaFiles(data);
      } catch (error) {
        console.error("Error fetching media data:", error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.onended = handleVideoEnd;
    }
  }, [mediaFiles]);

  // To display either video or image based on mediaType
  const displayMedia = () => {
    if (mediaFiles.length > 0) {
      const media = mediaFiles[currentIndex];
      console.log(`Displaying media: ${media.name}, type: ${media.type}`);

      if (mediaType === "video" && media.type === "mp4" && !showImage) {
        console.log("Displaying video...");
        return (
          <video
            ref={videoRef}
            autoPlay
            muted
            loop={false}
            className="video-player"
            src={`/api/tft/media/${media.name}`}
          />
        );
      } else if (mediaType === "image" && media.type !== "mp4") {
        console.log("Displaying image...");
        return (
          <img
            className="image-player"
            src={`/api/tft/media/${media.name}`}
            alt={media.name}
          />
        );
      }
    } else {
      console.log("Loading media...");
      return <p>Loading media...</p>;
    }
  };

  useEffect(() => {
    if (showImage) {
      // When the image is shown, set a timeout to automatically switch to next media
      const timeoutId = setTimeout(() => {
        console.log("Timeout reached. Switching media...");
        switchMedia();
      }, 5000); // Show the image for 5 seconds

      return () => clearTimeout(timeoutId); // Cleanup timeout on component unmount or image change
    }
  }, [showImage]);

  useEffect(() => {
    console.log(`Current mediaType: ${mediaType}, showImage: ${showImage}`);
  }, [mediaType, showImage]);

  return (
    <div className="main-container">
      {/* Text Section */}
      <div className="text-section">
        <span className="station-label">Next Station :</span>
        <h2 className="station-name"> New Delhi Railway Station</h2>
      </div>

      {/* Video or Image Section */}
      <div className="video-section">{displayMedia()}</div>

      {/* Marquee Section */}
      <div className="marquee-section">
        <marquee className="marquee-text">
          Enjoy a Pleasant Journey - UI2 Page
        </marquee>
      </div>
    </div>
  );
};

export default UI2;
