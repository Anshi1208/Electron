/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import "@css/UI3.css";

const UI2 = () => {
  const [showImage, setShowImage] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [mediaFiles, setMediaFiles] = useState([]);
  const [selectedMedia, setSelectedMedia] = useState(null);
  const videoRef = useRef(null);

  const getRandomIndex = (arrayLength) => Math.floor(Math.random() * arrayLength);

  const handleVideoEnd = () => {
    setShowImage(true); // Show image when the video ends
    setTimeout(() => {
      setShowImage(false); // Switch back to the video
      setCurrentImageIndex(getRandomIndex(mediaFiles.length)); // Pick a random image
      setCurrentVideoIndex(getRandomIndex(mediaFiles.length)); // Pick a random video
      videoRef.current.play(); // Restart the video
    }, 5000); // Show the image for 5 seconds
  };

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.onended = handleVideoEnd;
    }

    // Fetch media files from the API
    const fetchData = async () => {
      try {
        const response = await fetch("/api/tft/data");
        const data = await response.json();
        setMediaFiles(data); // Set the fetched media files
      } catch (error) {
        console.error("Error fetching media data:", error);
      }
    };

    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentVideoIndex, currentImageIndex]);

  const handleClick = (file) => {
    setSelectedMedia(file);
  };

  return (
    <div className="main-container">
      {/* Text Section */}
      <div className="text-section">
        <span className="station-label">Next Station :</span>
        <h2 className="station-name"> New Delhi Railway Station</h2>
      </div>

      {/* Video or Image Section */}
      <div className="video-section">
        {selectedMedia ? (
          selectedMedia.type === "directory" ? (
            <div>This is a directory</div>
          ) : selectedMedia.type === "mp4" ? (
            <video
              ref={videoRef}
              autoPlay
              muted
              className="video-player"
              src={`/api/tft/media/${selectedMedia.name}`}
            />
          ) : (
            <img
              className="image-player"
              src={`/api/tft/media/${selectedMedia.name}`}
              alt={selectedMedia.name}
            />
          )
        ) : showImage ? (
          <img
            className="image-player"
            src={`/api/tft/media/${mediaFiles[currentImageIndex]?.name}`}
            alt="Station"
          />
        ) : (
          <video
            ref={videoRef}
            autoPlay
            muted
            className="video-player"
            src={`/api/tft/media/${mediaFiles[currentVideoIndex]?.name}`}
          />
        )}
      </div>

      {/* Media Files Section */}
      <div className="file-list">
        {mediaFiles.map((file) => (
          <div
            key={file.name}
            className="file-item"
            onClick={() => handleClick(file)}
          >
            <p>{file.name}</p>
          </div>
        ))}
      </div>

      {/* Marquee Section */}
      <div className="marquee-section">
        <marquee className="marquee-text">
          Enjoy a Pleasant Journey - UI2 Page
        </marquee>
      </div>
    </div>
  );
};

export default UI2;
