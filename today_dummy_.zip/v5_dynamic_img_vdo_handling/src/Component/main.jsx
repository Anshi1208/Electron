// eslint-disable-next-line no-unused-vars
import React from "react";
import ReactDOM from "react-dom/client"; // Ensure you're using React 18's API
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import UI1 from "./UI1";
import HomePage from "./HomePage";
import UI2 from "./UI2"; // Create similar UI2 and UI3 components as needed
import UI3 from "./UI3";
import UI4 from "./UI4";
import UI5 from "./UI5";
import UI6 from "./UI6";
// import MediaList from "./MediaList";
// MediaList;
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <Router>
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/UI1" element={<UI1 />} />
      <Route path="/UI2" element={<UI2 />} />
      <Route path="/UI3" element={<UI3 />} />
      <Route path="/UI4" element={<UI4 />} />
      <Route path="/UI5" element={<UI5 />} />
      <Route path="/UI6" element={<UI6 />} />
    </Routes>
  </Router>
);
