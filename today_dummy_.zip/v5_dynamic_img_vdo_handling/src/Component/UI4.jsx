/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import "@css/UI2.css";
import img1 from "@content/add2/left.jpg";
import img2 from "@content/add2/train.jpg";
import vdo1 from "@content/add2/Chutki.mp4";
import vdo2 from "@content/add2/Coca_Cola_to_Turn_Up_the_Moment.mp4";
import vdo3 from "@content/add2/Fevikwik_Phenko_Nahi_Jodo.mp4";
import vdo4 from "@content/add2/Kalia Ustaad2.mp4";

const UI4 = () => {
  const [showImage, setShowImage] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const videoRef = useRef(null);

  // Arrays to hold the images and videos
  const images = [img1, img2];
  const videos = [vdo1, vdo2, vdo3, vdo4];

  const handleVideoEnd = () => {
    setShowImage(true); // Show image when the video ends
    setTimeout(() => {
      setShowImage(false); // Switch back to the video
      setCurrentIndex(Math.floor(Math.random() * videos.length)); // Randomly pick a new video
      videoRef.current.play(); // Restart the video
    }, 5000); // Show the image for 5 seconds
  };

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.onended = handleVideoEnd;
    }
  }, [currentIndex]);

  return (
    <div className="main-container">
      {/* Text Section */}
      <div className="text-section">
        <span className="station-label">Next Station :</span>
        <h2 className="station-name"> New Delhi Railway Station</h2>
      </div>

      {/* Video or Image Section */}
      <div className="video-section" style={{ height: "85vh" }}>
        {showImage ? (
          <img
            className="image-player"
            src={images[Math.floor(Math.random() * images.length)]} // Random image selection
            alt="Station"
          />
        ) : (
          <video
            ref={videoRef}
            autoPlay
            muted
            className="video-player"
            src={videos[Math.floor(Math.random() * videos.length)]} // Random video selection
          />
        )}
      </div>
    </div>
  );
};

export default UI4;
