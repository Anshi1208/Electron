/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import "@css/UI3.css";
import img1 from "@content/add2/left.jpg";
import img2 from "@content/add2/train.jpg";
import vdo1 from "@content/add2/Chutki.mp4"
import vdo2 from "@content/add2/Coca_Cola_to_Turn_Up_the_Moment.mp4";
import vdo3 from "@content/add2/Fevikwik_Phenko_Nahi_Jodo.mp4";
import vdo4 from "@content/add2/Kalia Ustaad2.mp4";

const UI2 = () => {
  const [showImage, setShowImage] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const videoRef = useRef(null);
  // Arrays to hold the images and videos
  const images = [img1, img2 ];
  const videos = [vdo1, vdo2, vdo3, vdo4];
   const getRandomIndex = (arrayLength) =>
     Math.floor(Math.random() * arrayLength);

  const handleVideoEnd = () => {
    setShowImage(true); // Show image when the video ends
    setTimeout(() => {
      setShowImage(false); // Switch back to the video
      setCurrentImageIndex(getRandomIndex(images.length)); // Pick a random image
      setCurrentVideoIndex(getRandomIndex(videos.length)); // Pick a random video
      videoRef.current.play(); // Restart the video
    }, 5000); // Show the image for 5 seconds
  };

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.onended = handleVideoEnd;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentVideoIndex, currentImageIndex]);

  return (
    <div className="main-container">
      {/* Text Section */}
      <div className="text-section">
        <span className="station-label">Next Station :</span>
        <h2 className="station-name"> New Delhi Railway Station</h2>
      </div>

      {/* Video or Image Section */}
      <div className="video-section">
        {showImage ? (
          <img
            className="image-player"
            src={images[currentImageIndex]}
            alt="Station"
          />
        ) : (
          <video
            ref={videoRef}
            autoPlay
            muted
            className="video-player"
            src={videos[currentVideoIndex]}
          />
        )}
      </div>

      {/* Marquee Section */}
      <div className="marquee-section">
        <marquee className="marquee-text">
          Enjoy a Pleasant Journey - UI2 Page
        </marquee>
      </div>
    </div>
  );
};

export default UI2;
