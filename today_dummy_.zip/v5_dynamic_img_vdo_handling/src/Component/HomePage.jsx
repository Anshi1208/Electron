/* eslint-disable no-unused-vars */
import React from "react";
import { Link } from "react-router-dom";
import img1 from "@assets/UI - 1.png";
import img2 from "@assets/UI - 2.png";
import img3 from "@assets/UI - 3.png";
import img4 from "@assets/UI - 4.png";
import img5 from "@assets/UI - 5.png";
import img6 from "@assets/UI - 6.png";
import "@css/HomePage.css";

const HomePage = () => {
  return (
    <div className="home-container">
      <div className="option">
        <Link to="/UI1">
          <img src={img1} alt="UI1" />
          <p>Trigger-1</p>
        </Link>
      </div>
      <div className="option">
        <Link to="/UI2">
          <img src={img2} alt="UI2" />
          <p>Trigger-2</p>
        </Link>
      </div>
      <div className="option">
        <Link to="/UI3">
          <img src={img3} alt="UI3" />
          <p>Trigger-3</p>
        </Link>
      </div>

      <div className="option">
        <Link to="/UI4">
          <img src={img4} alt="UI4" />
          <p>Trigger-4</p>
        </Link>
      </div>
      <div className="option">
        <Link to="/UI5">
          <img src={img5} alt="UI3" />
          <p>Trigger-5</p>
        </Link>
      </div>

      <div className="option">
        <Link to="/UI6">
          <img src={img6} alt="UI6" />
          <p>Trigger-6</p>
        </Link>
      </div>
    </div>
  );
};

export default HomePage;
