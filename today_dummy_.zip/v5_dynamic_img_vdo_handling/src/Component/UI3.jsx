/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import "@css/UI2.css";
import img1 from "@content/add2/left.jpg";
import img2 from "@content/add2/train.jpg";
import vdo1 from "@content/add2/Chutki.mp4";
import vdo2 from "@content/add2/Coca_Cola_to_Turn_Up_the_Moment.mp4";
import vdo3 from "@content/add2/Fevikwik_Phenko_Nahi_Jodo.mp4";
import vdo4 from "@content/add2/Kalia Ustaad2.mp4";

const UI4 = () => {
  const [currentStep, setCurrentStep] = useState("video");
  const [currentIndex, setCurrentIndex] = useState(0);
  const videoRef = useRef(null);

  // Arrays for images and videos
  const images = [img1, img2];
  const videos = [vdo1, vdo2, vdo3, vdo4];

  const handleVideoEnd = () => {
    setCurrentStep("image"); // Switch to image after video ends
  };

  useEffect(() => {
    if (videoRef.current && currentStep === "video") {
      videoRef.current.onended = handleVideoEnd;
    }
  }, [currentStep]);

  useEffect(() => {
    let timer;

    if (currentStep === "image") {
      timer = setTimeout(() => {
        setCurrentStep("text");
      }, 5000); // Show image for 5 seconds
    } else if (currentStep === "text") {
      timer = setTimeout(() => {
        setCurrentStep("video");
        // Set random index for next video
        setCurrentIndex(Math.floor(Math.random() * videos.length));
      }, 3000); // Show text for 3 seconds
    }

    return () => clearTimeout(timer);
  }, [currentStep]);

  return (
    <div className="main-container">
      {/* Conditional Rendering */}
      {currentStep === "video" && (
        <video
          ref={videoRef}
          autoPlay
          muted
          className="video-player"
          src={videos[currentIndex % videos.length]} // Use currentIndex for videos
        />
      )}

      {currentStep === "image" && (
        <img
          className="image-player"
          src={images[Math.floor(Math.random() * images.length)]} // Random image selection
          alt="Station"
        />
      )}

      {currentStep === "text" && (
        <div className="text-message">
          <h1>Welcome to the Indian Railway</h1>
        </div>
      )}
    </div>
  );
};

export default UI4;
