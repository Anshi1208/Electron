/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import "@css/UI1.css";
import img1 from "@content/add2/left.jpg";
import img2 from "@content/add2/train.jpg";
import img3 from "@content/add2/metro.jpg";
import vdo1 from "@content/add2/Chutki.mp4";
import vdo2 from "@content/add2/Coca_Cola_to_Turn_Up_the_Moment.mp4";
import vdo3 from "@content/add2/Fevikwik_Phenko_Nahi_Jodo.mp4";
import vdo4 from "@content/add2/Kalia Ustaad2.mp4";

const UI1 = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const videoRef = useRef(null);

  // Array with mixed media
  const media = [img1, img2, img3, vdo1, vdo2, vdo3, vdo4];

  // Separate images and videos based on file extension
  const images = media.filter((item) => item.match(/\.(jpg|jpeg|png|gif)$/i));
  const videos = media.filter((item) => item.match(/\.(mp4|mov|avi|mkv)$/i));

  // Loop images continuously
  useEffect(() => {
    let imageTimer = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 4000); // Change image every 4 seconds

    return () => clearInterval(imageTimer);
  }, []);

  // Handle video loop
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.addEventListener("ended", handleVideoEnd);
      videoRef.current.play();
    }
    return () => {
      if (videoRef.current) {
        videoRef.current.removeEventListener("ended", handleVideoEnd);
      }
    };
  }, [currentVideoIndex]);

  const handleVideoEnd = () => {
    setCurrentVideoIndex((prevIndex) => (prevIndex + 1) % videos.length);
  };

  return (
    <div className="container">
      {/* Left Section (Image Loop) */}
      <div className="image1-section">
        <img
          className="image-player"
          src={images[currentImageIndex]}
          alt="Station"
        />
      </div>

      {/* Right Section (Video Loop) */}
      <div className="video-container">
        <div className="text-container">
          <h2>Current Station: Delhi</h2>
        </div>
        <div className="video-player-container">
          <video
            ref={videoRef}
            autoPlay
            muted
            className="video-player"
            src={videos[currentVideoIndex]}
          />
        </div>
      </div>
    </div>
  );
};

export default UI1;
