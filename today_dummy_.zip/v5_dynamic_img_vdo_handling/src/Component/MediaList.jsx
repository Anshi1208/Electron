/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";

const MediaList = () => {
  const [mediaFiles, setMediaFiles] = useState([]);
  const [selectedMedia, setSelectedMedia] = useState(null);

  useEffect(() => {
    // Fetch media files from the API
    const fetchData = async () => {
      try {
        const response = await fetch("/api/tft/data");
        const data = await response.json();
        // console.log(data);
        const check = data.map((data) => { 
          console.log(data.name)
        })
        setMediaFiles(data);
      } catch (error) {
        console.error("Error fetching media data:", error);
      }
    };

    fetchData();
  }, []);

  const handleClick = (file) => {
    setSelectedMedia(file);
  };

  return (
    <div className="container">
      <div className="file-list">
        {mediaFiles.map((file) => (
          <div
            key={file.name}
            className="file-item"
            onClick={() => handleClick(file)}
          >
            <p>{file.name}</p>
          </div>
        ))}
      </div>

      {/* Display Selected Media */}
      {selectedMedia && (
        <div className="media-display">
          {selectedMedia.type === "directory" ? (
            <div>This is a directory</div>
          ) : selectedMedia.type === "mp4" ? (
            <video
              loop
              autoPlay
              muted
              className="video1-player"
              src={`/api/tft/media/${selectedMedia.name}`}
            />
          ) : (
            <img
              className="image"
              src={`/api/tft/media/${selectedMedia.name}`}
              alt={selectedMedia.name}
            />
          )}
        </div>
      )}
    </div>
  );
};

export default MediaList;
