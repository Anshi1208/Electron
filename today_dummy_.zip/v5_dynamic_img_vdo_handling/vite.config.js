/* eslint-disable no-constant-binary-expression */
/* eslint-disable no-undef */
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'
import { fileURLToPath } from 'url'

  // Ensure proper port setting and environment usage
const isProduction = process.env.NODE_ENV === 'production'
let loadEnvPath

// Custom paths to search for .env file
const envPath = ['./.env', './dist/Api/.env'] // Define your custom search paths

// Dynamically import the correct loadEnv based on NODE_ENV
try {
  if (isProduction) {
    console.log('Running in production mode')
    loadEnvPath = await import('./src/dist/Api/loadEnv')
  } else {
    console.log('Running in development mode')
    loadEnvPath = await import('./Api/loadEnv')
  }

  loadEnvPath.default()
} catch (error) {
  console.error('Error loading environment configuration:', error)
}


loadEnvPath.default(envPath)


// Define __dirname for ES module compatibility
const __dirname = path.dirname(fileURLToPath(import.meta.url))

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: process.env.VITE_PORT || 81 || 5179 || 5174, // Port number for the development server
    open: true, // Automatically open the browser on server start
    cors: true,
    host: "0.0.0.0",
    proxy: {
      "/api": {
        target: `http://localhost:${process.env.VITE_SERVER_PORT}`,
        changeOrigin: true,
        secure: false,
        credentials: true,
        rewrite: (path) => path.replace(/^\/api/, ""), // Remove `/api` prefix
      },
    },
  },
  resolve: {
    alias: {
      "@api": path.resolve(__dirname, isProduction ? "./dist/Api/" : "./Api"),
      "@css": path.resolve(__dirname, "./src/CSS"), // Alias for CSS folder
      "@components": path.resolve(__dirname, "./src/Component/"), // Alias for Components folder
      "@assets": path.resolve(__dirname, "./src/Assets"), // Alias for assets folder
      "@content": path.resolve(__dirname, "./src/content"),
    },
  },
});
