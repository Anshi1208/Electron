/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import express from 'express'
import cors from 'cors'
import fs from 'fs'
import path from 'path'
import { createServer } from 'http'
import loadEnv from './loadEnv.js'
import TftData from "./TftData.js";
const app = express()

// Custom paths to search for .env file
const envPath = ['./.env', '../.env']; // Define your custom search paths

// Call the loadEnv function with custom paths
const result = loadEnv(envPath);

const PORT = process.env.VITE_SERVER_PORT || 5000

app.use(cors())

app.use(express.json())

const server = createServer(app)

// Use the TftData routes
TftData(app)

// Global error handler
app.use((error, req, res, next) => {
  console.error(`Global error handler caught an error: ${error.message}`)

  // Send a response to the client
  res.status(500).send('An unexpected error occurred')

  // After sending the response, restart the server after 10 seconds
  server.close(() => {
    console.log('Server is restarting after an error...')
    setTimeout(startServerWithRetry, 5000) // Restart server after 10 seconds
  })
})

const startServerWithRetry = () => {
  try {
    server.listen(PORT, '0.0.0.0', () => {
      console.log(`Server is running on port ${PORT}`)
    })
  } catch (error) {
    console.error(`Server encountered an error: ${error.message}`)
    console.log('Retrying server startup in 10 seconds...')
    setTimeout(startServerWithRetry, 10000)
  }
}

// Catch uncaught exceptions and unhandled promise rejections
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error.message)
  server.close(() => {
    console.log('Server is restarting after an uncaught exception...')
    setTimeout(startServerWithRetry, 10000)
  })
})

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason)
  server.close(() => {
    console.log('Server is restarting after an unhandled rejection...')
    setTimeout(startServerWithRetry, 10000)
  })
})

// Start server with retry logic
startServerWithRetry()