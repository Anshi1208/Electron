const sqlite3 = require('sqlite3').verbose()
const db = new sqlite3.Database('./users.db') // This will create/open the 'users.db' SQLite database

// Create a table for users if it doesn't exist
db.serialize(() => {
  db.run(
    'CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, email TEXT)'
  )
})

// Function to add a user
function addUser(username, password, email) {
  const stmt = db.prepare(
    'INSERT INTO users (username, password, email) VALUES (?, ?, ?)'
  )
  stmt.run(username, password, email, function (err) {
    if (err) {
      console.error('Error adding user:', err)
    } else {
      console.log(`User ${username} added successfully`)
    }
  })
  stmt.finalize()
}

// Function to get user by username
function getUserByUsername(username, callback) {
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, row) => {
    callback(row)
  })
}

// Function to update user password (for "Forgot Password" feature)
function updateUserPassword(username, newPassword) {
  const stmt = db.prepare('UPDATE users SET password = ? WHERE username = ?')
  stmt.run(newPassword, username, function (err) {
    if (err) {
      console.error('Error updating password:', err)
    } else {
      console.log(`Password updated for ${username}`)
    }
  })
  stmt.finalize()
}

module.exports = { addUser, getUserByUsername, updateUserPassword }
