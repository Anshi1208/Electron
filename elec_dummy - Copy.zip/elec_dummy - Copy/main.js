const { app, BrowserWindow, ipcMain, dialog } = require('electron')
const sqlite3 = require('sqlite3').verbose()

let mainWindow, loginWindow
const db = new sqlite3.Database('./users.db')

// Create Users table if it doesn't exist
db.serialize(() => {
  db.run(
    'CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, email TEXT)'
  )
})

app.whenReady().then(() => {
  createLoginWindow()
})

function createLoginWindow() {
  loginWindow = new BrowserWindow({
    width: 400,
    height: 300,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true,
    },
  })

  loginWindow.loadFile('login.html') // Load login page
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true,
    },
  })

  mainWindow.loadFile('index.html') // Load main page
}

ipcMain.on('authenticate', (event, { username, password }) => {
  db.get(
    'SELECT * FROM users WHERE username = ? AND password = ?',
    [username, password],
    (err, row) => {
      if (err) {
        console.error(err)
      }
      if (row) {
        createMainWindow()
        if (loginWindow) loginWindow.close()
      } else {
        dialog.showErrorBox('Login Failed', 'Invalid username or password.')
      }
    }
  )
})

ipcMain.on('reset-password', (event, resetUsername) => {
  db.get(
    'SELECT * FROM users WHERE username = ? OR email = ?',
    [resetUsername, resetUsername],
    (err, row) => {
      if (err) {
        console.error(err)
      }
      if (row) {
        // User exists, prompt for new password
        dialog
          .showInputBox({
            title: 'New Password',
            message: 'Enter a new password:',
          })
          .then((result) => {
            if (result.response) {
              const newPassword = result.response
              db.run(
                'UPDATE users SET password = ? WHERE id = ?',
                [newPassword, row.id],
                (err) => {
                  if (err) {
                    console.error(err)
                  } else {
                    dialog.showMessageBox({
                      message: 'Password reset successful!',
                      buttons: ['OK'],
                    })
                  }
                }
              )
            }
          })
      } else {
        // User doesn't exist, prompt for creating a new account
        dialog
          .showMessageBox({
            message: 'User not found. Would you like to create a new account?',
            buttons: ['Yes', 'No'],
          })
          .then((response) => {
            if (response.response === 0) {
              // Create new account
              dialog
                .showInputBox({
                  title: 'Create New Account',
                  message: 'Enter new username:',
                })
                .then((result) => {
                  const newUsername = result.response
                  if (newUsername) {
                    dialog
                      .showInputBox({
                        title: 'Create New Account',
                        message: 'Enter new password:',
                      })
                      .then((result) => {
                        const newPassword = result.response
                        db.run(
                          'INSERT INTO users (username, password, email) VALUES (?, ?, ?)',
                          [newUsername, newPassword, resetUsername],
                          (err) => {
                            if (err) {
                              console.error(err)
                            } else {
                              dialog.showMessageBox({
                                message: 'Account created successfully!',
                                buttons: ['OK'],
                              })
                            }
                          }
                        )
                      })
                  }
                })
            }
          })
      }
    }
  )
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})
