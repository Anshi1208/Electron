const {  ipcMain, dialog } = require("electron");
const fs = require("fs");
const path = require("path");

const requiredSubfolders = [  
  'index.sys', 
  'videoadvertisementtime.txt',  
  'add',  
  'add2',   
  'poster',  
  'videos',        
  'kidszone',   
  'img',
  'music',     
  'movies', 
  'advertisment', 
];  
 


async function chooseDirectory(mainWindow) {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ["openDirectory"],
  });

  if (!result.canceled) {
    const directoryPath = result.filePaths[0];
    mainWindow.webContents.send("directory-chosen", directoryPath);
    handleDirectorySelection(directoryPath, mainWindow);
  }
}


function handleDirectorySelection(selectedDirectory, mainWindow) {
  const folderNames = path.basename(selectedDirectory);
  const missingFolders = checkSubfolders(selectedDirectory);
  mainWindow.webContents.send("selected-directory", folderNames);
  if (missingFolders.length === 0) {
    mainWindow.webContents.send("folder-status", true);
  } else {
    mainWindow.webContents.send("folder-status", false);
  }
}


function checkSubfolders(directory) {
  try {
    const folderNames = fs
      .readdirSync(directory)
      .map((name) => name.toLowerCase());
    const missingFolders = requiredSubfolders.filter(
      (subfolder) => !folderNames.includes(subfolder)
    );
    return missingFolders;
  } catch (error) {
    console.error("Error while checking subfolders:", error);
    return requiredSubfolders;
  }
}


module.exports = {
  chooseDirectory,
  handleDirectorySelection,
  checkSubfolders,
};
