const { ipcRenderer } = require("electron");

let selectedDirectory = ""; // Variable to store the selected directory folderLabel
const chooseDirButton = document.getElementById("chooseDirButton");
const submitButton = document.getElementById("submitButton");
const folderStatusElement = document.getElementById("statusMessage");
const folderLabel = document.getElementById("folderLabel");
const IpListContainer = document.getElementById("IpListContainer");
const sendButton = document.getElementById("SendButton");
// Fetch and display IP addresses on page load
// Add a click event listener to the folder label
folderLabel.addEventListener("click", () => {
  // Simulate a click on the choose button
  chooseDirButton.click();
});
ipcRenderer.on("get-ip-addresses", (event, ipAddresses) => {
  // Clear the container before populating
  IpListContainer.innerHTML = "";

  if (ipAddresses.length === 0) {
    console.log("No IP addresses found.");
    return;
  }
  ipAddresses.forEach((ipData) => {
    createIpListItem(ipData, true);
  });
});

let selectedIps = [];
ipcRenderer.on("ip-status-update", (event, updatedIpData) => {
  // Clear the container before populating
  IpListContainer.innerHTML = "";

  if (updatedIpData.length === 0) {
    console.log("No IP addresses found.");
    return;
  }
  updatedIpData.forEach((ipData) => {
    createIpListItem(ipData, false);
  });
});

function createIpListItem(ipData, boolean) {
  const listItem = document.createElement("div");
  listItem.classList.add("IpBox");

  listItem.innerHTML = `
  <div class="CheckboxContainer">
        <input type="checkbox" id="checkbox-${ipData.ip}" class="ip-checkbox">
        <label for="checkbox-${ipData.ip}">${ipData.alianceName}</label>
  </div>
  <div class="status-icon" id="status-${ipData.ip}"></div>
  `;

  IpListContainer.appendChild(listItem);

  const statusIcon = document.getElementById(`status-${ipData.ip}`);
  const checkbox = document.getElementById(`checkbox-${ipData.ip}`);

  updateStatusIcon(statusIcon, ipData.status);
  updateCheckboxStatus(checkbox, ipData.status, ipData.ip); // Call this to update checkbox status based on IP status

  // Restore checkbox state if IP was previously selected
  if (selectedIps.includes(ipData.ip)) {
    checkbox.checked = true;
  }

  checkbox.addEventListener("change", () => {
    if (checkbox.checked) {
      if (!selectedIps.includes(ipData.ip)) {
        selectedIps.push(ipData.ip); // Add the IP to selectedIps list
      }
    } else {
      const index = selectedIps.indexOf(ipData.ip);
      if (index > -1) selectedIps.splice(index, 1); // Remove the IP from selectedIps list
    }

    ipcRenderer.send("selectedIps", selectedIps); // Send the updated list to main process
    console.log("Selected IPs:", selectedIps);
  });
}

function updateStatusIcon(statusIcon, status) {
  if (status === "active") {
    statusIcon.innerHTML = "✔️";
    statusIcon.style.color = "green";
  } else {
    statusIcon.innerHTML = "❌";
    statusIcon.style.color = "red";
  }
}

// Function to update checkbox status and background based on the IP's status
function updateCheckboxStatus(checkbox, status, ip) {
  if (status === "active") {
    checkbox.disabled = false; // Enable checkbox if status is active
    checkbox.style.backgroundColor = "white"; // Set background to white if active
  } else {
    checkbox.disabled = true; // Disable checkbox if status is not active
    checkbox.style.backgroundColor = "#ccc"; // Set background to gray if inactive
    if (checkbox.checked) {
      checkbox.checked = false; // Automatically uncheck if the status is inactive
    }

    // Remove the IP from selectedIps list if it becomes inactive
    const index = selectedIps.indexOf(ip);
    if (index > -1) selectedIps.splice(index, 1);
  }
}

// Open the directory dialog when "Choose Directory" button is clicked
chooseDirButton.addEventListener("click", () => {
  ipcRenderer.send("choose-directory"); // Request the main process to open directory dialog
});

// Listen for the selected directory from the main process
ipcRenderer.on("selected-directory", (event, directory) => {
  selectedDirectory = directory; // Update the selected directory
  // console.log('Selected directory:', selectedDirectory);

  if (folderLabel) {
    folderLabel.textContent = `${selectedDirectory}`; // Update status message
  }
});

ipcRenderer.on("folder-status", (event, msg) => {
  if (msg == true) {
    selectedDirectory = "Folder selected successfully";
    folderStatusElement.style.color = "green";
  } else if (msg == false) {
    selectedDirectory = "Wrong folder selected";
    folderStatusElement.style.color = "red";
  } else {
    selectedDirectory = "Invalid selection";
    folderStatusElement.style.color = "red";
  }

  // Debugging: Log the current state of the Send button
  console.log("Send Button Disabled:", sendButton.disabled);
});

// Handle the submit button click event
submitButton.addEventListener("click", () => {
  if (!selectedDirectory) {
    folderStatusElement.textContent = "Kindly choose a folder first...";
  } else {
    // console.log("Selected directory:", selectedDirectory);
    if (folderStatusElement) {
      folderStatusElement.textContent = `${selectedDirectory}`;
    }
    if (selectedDirectory === "Folder selected successfully") {
      sendButton.disabled = false; // Enable the Send button
      sendButton.style.backgroundColor = "#2196F3";
    } else {
      sendButton.disabled = true; // Enable the Send button
      sendButton.style.backgroundColor = "#ccc";
    }
  }
  setTimeout(() => {
    folderStatusElement.textContent = "";
  }, 3000);
});
sendButton.addEventListener("click", () => {
  // console.log("sendButton clicked ", selectedIps);
  if (selectedIps.length === 0) {
    console.log("No IP addresses selected.");
    folderStatusElement.textContent = "Kindly choose a IP first...";
  }

  ipcRenderer.send("upload-folder", { selectedIps, selectedDirectory });
});
setTimeout(() => {
  folderStatusElement.textContent = "";
}, 3000);
