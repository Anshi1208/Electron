const { contextBridge, ipcRenderer } = require("electron");

// Exposing an API to the renderer process
contextBridge.exposeInMainWorld("electron", {
  login: (username, password) =>
    ipcRenderer.invoke("login", { username, password }),
  updatePassword: (data) => ipcRenderer.invoke("updatePassword", data),
});
