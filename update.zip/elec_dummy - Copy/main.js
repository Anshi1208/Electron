const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const bcrypt = require("bcryptjs");
let win;

function createWindow() {
  win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, "frontend", "preload.js"),
    },
  });

  win.loadFile("./frontend/login.html");
}

// Simulated stored hash from DB (this would be from your database in a real app)
let storedHashedPassword =
  "$2a$10$jb9L7ThaLPUwv0S3bw7YOO1KJO4at1kgeN8.r3FSfbIy96nG4r0Mq"; // Example hash for the old password

ipcMain.handle("login", async (event, { username, password }) => {
  console.log("Login attempt with:", { username, password });

  // Compare user-entered password with stored hash
  const passwordMatch = await bcrypt.compare(password, storedHashedPassword);

  if (passwordMatch) {
    console.log("Password match!");
    return { success: true, token: "dummy_token" };
  } else {
    console.log("Password does not match!");
    return { success: false, message: "Invalid username or password" };
  }
});

// Handle password update request
ipcMain.handle(
  "updatePassword",
  async (event, { username, oldPassword, newPassword }) => {
    try {
      console.log("Updating password for user:", username);

      // Call the function to update the password
      const updateResult = await updatePasswordInDatabase(
        username,
        oldPassword,
        newPassword
      );

      return updateResult; // Returning the result to the renderer process
    } catch (error) {
      console.error("Error during password update:", error);
      return { success: false, message: "Error during password update." };
    }
  }
);

// Function to update the password in the database
async function updatePasswordInDatabase(username, oldPassword, newPassword) {
  // Example logic to update the password (could be connecting to a database)

  // Compare old password with the stored hashed password
  const oldPasswordMatch = await bcrypt.compare(
    oldPassword,
    storedHashedPassword
  );

  if (!oldPasswordMatch) {
    // If old password does not match
    return { success: false, message: "Old password does not match." };
  }

  // Hash new password before updating
  const newHashedPassword = await bcrypt.hash(newPassword, 10);

  // Simulate a successful password update
  console.log(`Password for ${username} updated to: ${newHashedPassword}`);

  // Update the stored password hash with the new one (this would be saved in your database in a real application)
  storedHashedPassword = newHashedPassword;

  // Return success
  return { success: true, message: "Password updated successfully." };
}

// Create the window when app is ready
app.whenReady().then(createWindow);

// Quit app when all windows are closed (for macOS)
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
