const express = require("express");
const mysql = require("mysql2");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

// Import dotenv
require("dotenv").config();

// Initialize Express app
const app = express();
app.use(express.json());

// Create MySQL connection
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

// Connect to MySQL
db.connect((err) => {
  if (err) throw err;
  console.log("Connected to MySQL database!");
});

// Example login route
app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  console.log("Received Username:", username);
  console.log("Received Password:", password);
  const storedHashedPassword = await getStoredHashedPassword(username); // This should be a function fetching the stored hash from DB or file

  if (!storedHashedPassword) {
    return res.status(400).json({ message: "User not found" });
  }

  // Compare the password with the hashed password
  bcrypt.compare(password, storedHashedPassword, (err, isMatch) => {
    if (err) {
      console.error("Error comparing passwords:", err); // Log any comparison errors
      return res.status(500).json({ message: "Internal server error" });
    }

    console.log("Password match result:", isMatch); // Log whether passwords match
    if (isMatch) {
      const token = generateToken(username); // Assume you generate a JWT token here
      res.json({ token });
    } else {
      res.status(400).json({ message: "Invalid username or password" });
    }
  });
});
// Update Password Route
app.post("/update-password", (req, res) => {
  const { username, oldPassword, newPassword } = req.body;

  db.query(
    "SELECT * FROM users WHERE username = ?",
    [username],
    async (err, results) => {
      if (err) return res.status(500).send("Server error");
      if (results.length === 0) return res.status(404).send("User not found");

      const user = results[0];

      // Compare old password
      const passwordMatch = await bcrypt.compare(oldPassword, user.password);

      if (!passwordMatch) {
        return res.status(400).send("Old password is incorrect");
      }

      // Hash the new password
      bcrypt.hash(newPassword, 10, (err, hashedPassword) => {
        if (err) return res.status(500).send("Error hashing password");

        // Update the password in the database
        db.query(
          "UPDATE users SET password = ? WHERE username = ?",
          [hashedPassword, username],
          (err, result) => {
            if (err) return res.status(500).send("Error updating password");
            res.send("Password successfully updated");
          }
        );
      });
    }
  );
});


// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
